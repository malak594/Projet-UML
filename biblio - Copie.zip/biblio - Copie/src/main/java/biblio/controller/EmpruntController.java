package biblio.controller;


import biblio.dao.EmpruntDAO;
import biblio.dao.LivreDAO;
import biblio.dao.AdherentDAO;
import biblio.model.Emprunt;
import biblio.model.Livre;
import biblio.model.Adherent;
import java.time.LocalDate;
import java.util.List;

public class EmpruntController {
    private EmpruntDAO empruntDAO;
    private LivreDAO livreDAO;
    private AdherentDAO adherentDAO;
    private LivreController livreController;
    private AdherentController adherentController;

    public EmpruntController(EmpruntDAO empruntDAO, LivreDAO livreDAO, AdherentDAO adherentDAO,
                             LivreController livreController, AdherentController adherentController) {
        this.empruntDAO = empruntDAO;
        this.livreDAO = livreDAO;
        this.adherentDAO = adherentDAO;
        this.livreController = livreController;
        this.adherentController = adherentController;
    }

    /**
     * Crée un nouvel emprunt
     */
    public boolean creerEmprunt(int adherentId, String isbn) {
        // Vérifier si l'adhérent existe
        Adherent adherent = adherentDAO.trouverParId(adherentId);
        if (adherent == null) {
            return false;
        }

        // Vérifier si le livre existe
        Livre livre = livreDAO.trouverParIsbn(isbn);
        if (livre == null) {
            return false;
        }

        // Vérifier les contraintes
        if (!peutEmprunter(adherentId, isbn)) {
            return false;
        }

        // Créer l'emprunt
        Emprunt emprunt = new Emprunt(livre, adherent);
        empruntDAO.ajouter(emprunt);

        // Mettre à jour les compteurs
        livreController.decrementerExemplairesDisponibles(isbn);
        adherentController.incrementerEmprunts(adherentId);

        biblio.util.Logger.log("Nouvel emprunt - Adhérent: " + adherentId + ", Livre: " + isbn, 
                       adherentController.estAdmin() ? "ADMIN" : "USER");
        return true;
    }

    /**
     * Vérifie si un emprunt est possible
     */
    public boolean peutEmprunter(int adherentId, String isbn) {
        // Vérifier si l'adhérent peut emprunter
        if (!adherentController.peutEmprunter(adherentId)) {
            return false;
        }

        // Vérifier si le livre est disponible
        if (!livreController.estDisponiblePourEmprunt(isbn)) {
            return false;
        }

        // Vérifier si l'adhérent a déjà emprunté ce livre
        if (empruntDAO.adherentAEmprunteLivre(adherentId, isbn)) {
            return false;
        }

        return true;
    }

    /**
     * Retourne un livre emprunté
     */
    public boolean retournerLivre(int empruntId) {
        Emprunt emprunt = empruntDAO.trouverParId(empruntId);
        if (emprunt == null || !"ACTIF".equals(emprunt.getStatut())) {
            return false;
        }

        // Marquer comme retourné
        emprunt.setDateRetourReelle(LocalDate.now());
        emprunt.setStatut("TERMINE");
        
        // Mettre à jour la base de données
        empruntDAO.retourner(empruntId);

        // Mettre à jour les compteurs
        livreController.incrementerExemplairesDisponibles(emprunt.getLivre().getIsbn());
        adherentController.decrementerEmprunts(emprunt.getAdherent().getId());

        // Vérifier et gérer les retards
        gererRetard(emprunt);

        biblio.util.Logger.log("Retour livre - Emprunt ID: " + empruntId, 
                       adherentController.estAdmin() ? "ADMIN" : "USER");
        return true;
    }

    /**
     * Gère les retards (bloque l'adhérent si retard > 10 jours)
     */
    private void gererRetard(Emprunt emprunt) {
        int joursRetard = emprunt.calculerRetard();
        if (joursRetard > 10) {
            adherentController.bloquerAdherent(emprunt.getAdherent().getId(), true);
            biblio.util.Logger.log("Adhérent bloqué pour retard - ID: " + emprunt.getAdherent().getId(), "SYSTEM");
        }
    }

    /**
     * Liste tous les emprunts
     */
    public List<Emprunt> listerTousLesEmprunts() {
        return empruntDAO.listerTous();
    }

    /**
     * Liste les emprunts actifs
     */
    public List<Emprunt> listerEmpruntsActifs() {
        return empruntDAO.listerEmpruntsActifs();
    }

    /**
     * Liste les emprunts d'un adhérent
     */
    public List<Emprunt> listerEmpruntsParAdherent(int adherentId) {
        return empruntDAO.listerEmpruntsParAdherent(adherentId);
    }

    /**
     * Liste les emprunts en retard
     */
    public List<Emprunt> listerRetards() {
        return empruntDAO.listerRetards();
    }

    /**
     * Recherche un emprunt par son ID
     */
    public Emprunt rechercherEmpruntParId(int id) {
        return empruntDAO.trouverParId(id);
    }

    /**
     * Renouvelle un emprunt (prolonge la date de retour)
     */
    public boolean renouvelerEmprunt(int empruntId) {
        Emprunt emprunt = empruntDAO.trouverParId(empruntId);
        if (emprunt == null || !"ACTIF".equals(emprunt.getStatut())) {
            return false;
        }

        // Vérifier si l'emprunt n'est pas déjà en retard
        if (emprunt.calculerRetard() > 0) {
            return false;
        }

        // Prolonger de 14 jours supplémentaires
        emprunt.setDateRetourPrevue(emprunt.getDateRetourPrevue().plusDays(14));
        
        biblio.util.Logger.log("Renouvellement emprunt ID: " + empruntId, 
                       adherentController.estAdmin() ? "ADMIN" : "USER");
        return true;
    }

    /**
     * Compte le nombre d'emprunts actifs d'un adhérent
     */
    public int compterEmpruntsActifs(int adherentId) {
        return empruntDAO.compterEmpruntsActifsParAdherent(adherentId);
    }

    /**
     * Génère des statistiques
     */
    public String genererStatistiques() {
        int totalEmprunts = empruntDAO.listerTous().size();
        int empruntsActifs = empruntDAO.listerEmpruntsActifs().size();
        int retards = empruntDAO.listerRetards().size();
        
        return String.format(
            "Statistiques:\n" +
            "Total emprunts: %d\n" +
            "Emprunts actifs: %d\n" +
            "Retards: %d\n" +
            "Taux de retour: %.1f%%",
            totalEmprunts, empruntsActifs, retards,
            totalEmprunts > 0 ? ((totalEmprunts - empruntsActifs) * 100.0 / totalEmprunts) : 0
        );
    }
}