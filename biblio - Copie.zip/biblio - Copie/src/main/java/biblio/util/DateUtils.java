package biblio.util;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.temporal.ChronoUnit;

/**
 * Utilitaires pour la manipulation des dates
 */
public class DateUtils {
    
    public static final DateTimeFormatter DISPLAY_FORMATTER = 
        DateTimeFormatter.ofPattern("dd/MM/yyyy");
    public static final DateTimeFormatter DATABASE_FORMATTER = 
        DateTimeFormatter.ofPattern("yyyy-MM-dd");
    
    /**
     * Formate une date pour l'affichage
     * @param date La date à formater
     * @return La date formatée ou "N/A" si null
     */
    public static String formatForDisplay(LocalDate date) {
        if (date == null) {
            return "N/A";
        }
        return date.format(DISPLAY_FORMATTER);
    }
    
    /**
     * Formate une date pour la base de données
     * @param date La date à formater
     * @return La date formatée ou null
     */
    public static String formatForDatabase(LocalDate date) {
        if (date == null) {
            return null;
        }
        return date.format(DATABASE_FORMATTER);
    }
    
    /**
     * Parse une date depuis un string d'affichage
     * @param dateString Le string de date
     * @return La LocalDate ou null si parsing échoue
     */
    public static LocalDate parseFromDisplay(String dateString) {
        if (dateString == null || dateString.trim().isEmpty()) {
            return null;
        }
        
        try {
            return LocalDate.parse(dateString.trim(), DISPLAY_FORMATTER);
        } catch (DateTimeParseException e) {
            return null;
        }
    }
    
    /**
     * Parse une date depuis un string de base de données
     * @param dateString Le string de date
     * @return La LocalDate ou null si parsing échoue
     */
    public static LocalDate parseFromDatabase(String dateString) {
        if (dateString == null || dateString.trim().isEmpty()) {
            return null;
        }
        
        try {
            return LocalDate.parse(dateString.trim(), DATABASE_FORMATTER);
        } catch (DateTimeParseException e) {
            return null;
        }
    }
    
    /**
     * Calcule la différence en jours entre deux dates
     * @param date1 Première date
     * @param date2 Deuxième date
     * @return Nombre de jours entre les deux dates
     */
    public static long daysBetween(LocalDate date1, LocalDate date2) {
        if (date1 == null || date2 == null) {
            return 0;
        }
        return ChronoUnit.DAYS.between(date1, date2);
    }
    
    /**
     * Vérifie si une date est dans le futur
     * @param date La date à vérifier
     * @return true si la date est dans le futur, false sinon
     */
    public static boolean isFutureDate(LocalDate date) {
        if (date == null) {
            return false;
        }
        return date.isAfter(LocalDate.now());
    }
    
    /**
     * Vérifie si une date est dans le passé
     * @param date La date à vérifier
     * @return true si la date est dans le passé, false sinon
     */
    public static boolean isPastDate(LocalDate date) {
        if (date == null) {
            return false;
        }
        return date.isBefore(LocalDate.now());
    }
    
    /**
     * Vérifie si une date est aujourd'hui
     * @param date La date à vérifier
     * @return true si la date est aujourd'hui, false sinon
     */
    public static boolean isToday(LocalDate date) {
        if (date == null) {
            return false;
        }
        return date.isEqual(LocalDate.now());
    }
    
    /**
     * Ajoute des jours ouvrables (exclut les weekends)
     * @param startDate Date de départ
     * @param workingDays Nombre de jours ouvrables à ajouter
     * @return La date finale
     */
    public static LocalDate addWorkingDays(LocalDate startDate, int workingDays) {
        if (startDate == null) {
            return null;
        }
        
        LocalDate result = startDate;
        int addedDays = 0;
        
        while (addedDays < workingDays) {
            result = result.plusDays(1);
            // Si ce n'est pas samedi (6) ni dimanche (7)
            if (result.getDayOfWeek().getValue() < 6) {
                addedDays++;
            }
        }
        
        return result;
    }
    
    /**
     * Vérifie si une date est un weekend
     * @param date La date à vérifier
     * @return true si c'est un weekend, false sinon
     */
    public static boolean isWeekend(LocalDate date) {
        if (date == null) {
            return false;
        }
        int dayOfWeek = date.getDayOfWeek().getValue();
        return dayOfWeek == 6 || dayOfWeek == 7; // Samedi ou dimanche
    }
}